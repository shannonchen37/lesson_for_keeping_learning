from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import xlrd

data=xlrd.open_workbook('python实验用名单.xls')
table=data.sheet_by_name('Sheet1')
location=table.col_values(4)[1:]
#print(location)
Llist=[]
for place in location:
	if "省" in place:
		Llist.append(place[:-1])
	elif '市' in place:
		Llist.append(place[:-1])
	else:
		Llist.append(place)
while '' in Llist:
    Llist.remove('')
print(Llist)

Llist_num = defaultdict(int)
for i in range(len(Llist)):
	Llist_num[Llist[i]] += 1
Llist_sort = sorted(Llist_num.items(), key=lambda x:x[1], reverse=True)
print(Llist_sort)

total_c = len(Llist_sort)   # 总长度
head_num = len(Llist_sort) 
x = np.array(range(head_num))
y_c = []
xlabel_c = []
for tupe in Llist_sort[0:head_num]:
    y_c.append(tupe[1])
    xlabel_c.append(tupe[0])

#print(y_c)
#print(x)
mpl.rcParams['font.sans-serif'] = ['SimHei'] #设置中文字体 
#plt.figure(figsize=(40, 5), dpi=150)
plt.bar(x, y_c)
plt.xticks(x, xlabel_c)
plt.xticks(rotation=45)
for a, b in zip(x, y_c):
    plt.text(a-1, b+3, b)
plt.show()