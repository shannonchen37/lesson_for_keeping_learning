from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import xlrd

data=xlrd.open_workbook('python实验用名单.xls')
table=data.sheet_by_name('Sheet1')
sex=table.col_values(1)[1:]
year_list=table.col_values(3)[1:]


male=[0,0,0,0,0,0,0]
female=[0,0,0,0,0,0,0]
for i in range(len(sex)):
	if year_list[i]==2012:
		if sex[i]=='男':
			male[0]=male[0]+1
		else:
			female[0]=female[0]+1
	elif year_list[i]==2013:
		if sex[i]=='男':
			male[1]=male[1]+1
		else:
			female[1]=female[1]+1
	elif year_list[i]==2014:
		if sex[i]=='男':
			male[2]=male[2]+1
		else:
			female[2]=female[2]+1
	elif year_list[i]==2015:
		if sex[i]=='男':
			male[3]=male[3]+1
		else:
			female[3]=female[3]+1
	elif year_list[i]==2016:
		if sex[i]=='男':
			male[4]=male[4]+1
		else:
			female[4]=female[4]+1
	elif year_list[i]==2017:
		if sex[i]=='男':
			male[5]=male[5]+1
		else:
			female[5]=female[5]+1
	else:
		if sex[i]=='男':
			male[6]=male[6]+1
		else:
			female[6]=female[6]+1

#print(male)
#print(female)

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

barWidth = 0.25
r1 = np.arange(len(male))
r2 = [x + barWidth for x in r1]

plt.bar(r1, male, color='#00BBFF', width=barWidth, edgecolor='white', label='male')
plt.bar(r2, female, color='#FF0088', width=barWidth, edgecolor='white', label='female')


plt.xticks([r + barWidth for r in range(len(male))], ['2012','2013','2014','2015','2016','2017','2018'])
plt.legend()
plt.show()







