from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import xlrd

data=xlrd.open_workbook('python实验用名单.xls')
table=data.sheet_by_name('Sheet1')
name_list=table.col_values(0)[1:]
#print(name_list)
last_name = []
for name in name_list:
   if '·' in name:
      name1, name2 = name.split("·")
      last_name.append(name1)
   elif len(name) == 4:
      last_name.append(name[:2])
   else:
      last_name.append(name[0:1])
print(last_name)
last_num = defaultdict(int)
for i in range(len(last_name)):
   last_num[last_name[i]] += 1
last_sort = sorted(last_num.items(), key=lambda x:x[1], reverse=True)
#print(last_sort)
cnts=[]
total_cnt=0
for tupe in last_sort[0:5]:
   cnts.append(tupe[1])
for i in cnts:
   total_cnt +=i
a=int((cnts[0]/total_cnt)*100)
b=int((cnts[1]/total_cnt)*100)
c=int((cnts[2]/total_cnt)*100)
d=int((cnts[3]/total_cnt)*100)
e=int((cnts[4]/total_cnt)*100)
labels = '王', '张', '李', '陈','刘'
sizes = [a,b,c,d,e] #占比
colors = ['yellowgreen', 'gold', '#FF0000','#0000FF','#9F5887'] 
mpl.rcParams['font.sans-serif'] = ['SimHei'] #设置中文字体 
fig = plt.figure()
ax = fig.gca()
ax.pie(sizes, labels=labels, colors=colors,
   autopct='%1.1f%%', shadow=False, startangle=90,
   radius=0.4, center=(0.5, 0.5), frame=True) 
plt.show()
