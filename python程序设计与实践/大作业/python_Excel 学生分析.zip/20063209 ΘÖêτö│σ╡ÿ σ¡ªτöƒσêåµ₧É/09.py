from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import xlrd

data=xlrd.open_workbook('python实验用名单.xls')
table=data.sheet_by_name('Sheet1')
sex=table.col_values(1)[1:]
xueyuan=table.col_values(2)[1:]


male=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
female=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,]
for i in range(len(sex)):
	if xueyuan[i]=="自动化学院":
		if sex[i]=='男':
			male[0]=male[0]+1
		else:
			female[0]=female[0]+1
	elif xueyuan[i]=='电子信息学院':
		if sex[i]=='男':
			male[1]=male[1]+1
		else:
			female[1]=female[1]+1
	elif xueyuan[i]=='计算机学院':
		if sex[i]=='男':
			male[2]=male[2]+1
		else:
			female[2]=female[2]+1
	elif xueyuan[i]=='管理学院':
		if sex[i]=='男':
			male[3]=male[3]+1
		else:
			female[3]=female[3]+1
	elif xueyuan[i]=='会计学院':
		if sex[i]=='男':
			male[4]=male[4]+1
		else:
			female[4]=female[4]+1
	elif xueyuan[i]=='机械工程学院':
		if sex[i]=='男':
			male[5]=male[5]+1
		else:
			female[5]=female[5]+1
	elif xueyuan[i]=='材料与环境工程学院':
		if sex[i]=='男':
			male[6]=male[6]+1
		else:
			female[6]=female[6]+1
	elif xueyuan[i]=='卓越学院、创新创业学院':
		if sex[i]=='男':
			male[7]=male[7]+1
		else:
			female[7]=female[7]+1
	elif xueyuan[i]=='网络空间安全学院、浙江保密学院':
		if sex[i]=='男':
			male[8]=male[8]+1
		else:
			female[8]=female[8]+1
	elif xueyuan[i]=='外国语学院':
		if sex[i]=='男':
			male[9]=male[9]+1
		else:
			female[9]=female[9]+1
	elif xueyuan[i]=='通信工程学院':
		if sex[i]=='男':
			male[10]=male[10]+1
		else:
			female[10]=female[10]+1
	elif xueyuan[i]=='数字媒体与艺术设计学院':
		if sex[i]=='男':
			male[11]=male[11]+1
		else:
			female[11]=female[11]+1
	elif xueyuan[i]=='生命信息与仪器工程学院':
		if sex[i]=='男':
			male[12]=male[12]+1
		else:
			female[12]=female[12]+1
	elif xueyuan[i]=='人文与法学院':
		if sex[i]=='男':
			male[13]=male[13]+1
		else:
			female[13]=female[13]+1
	elif xueyuan[i]=='理学院':
		if sex[i]=='男':
			male[14]=male[14]+1
		else:
			female[14]=female[14]+1
	elif xueyuan[i]=='经济学院':
		if sex[i]=='男':
			male[15]=male[15]+1
		else:
			female[15]=female[15]+1

print(male)
print(female)
total=male
for i in range(16):
	total[i]=total[i]+female[i]
print(total)

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

barWidth = 0.25
r1 = np.arange(len(male))
r2 = [x + barWidth for x in r1]

plt.bar(r1, total, color='#00BBFF', width=barWidth, edgecolor='white', label='male')

#plt.figure(figsize=(40, 5), dpi=150)
plt.xticks([r + barWidth for r in range(len(male))], ['自动化学院','电子信息学院','计算机学院','管理学院','会计学院','机械学院','环材学院','卓越学院','网安学院','外国语学院','通信学院','数媒学院','生仪学院','人文与法学院','理学院','经济学院'])
plt.xticks(rotation=45)
plt.legend()
plt.show()












