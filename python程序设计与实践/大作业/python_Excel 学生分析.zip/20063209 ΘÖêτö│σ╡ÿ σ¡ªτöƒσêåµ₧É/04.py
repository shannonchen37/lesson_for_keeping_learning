from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import xlrd
import pandas as pd

data=xlrd.open_workbook('python实验用名单.xls')
table=data.sheet_by_name('Sheet1')
name_list=table.col_values(0)[1:]
year_list=table.col_values(3)[1:]
first_name = []
for name in name_list:
   if '·' in name:
      name1, name2 = name.split("·")
      first_name.append(name2)
   elif len(name) == 4:
      first_name.append(name[2:])
   else:
      first_name.append(name[1:])

name_list[2012],name_list[2013],name_list[2014],name_list[2015],name_list[2016],name_list[2017],name_list[2018]=[],[],[],[],[],[],[]
for i in range(len(first_name)):
	if year_list[i]==2012:
		name_list[2012].append(first_name[i])
	elif year_list[i]==2013:
		name_list[2013].append(first_name[i])
	elif year_list[i]==2014:
		name_list[2014].append(first_name[i])
	elif year_list[i]==2015:
		name_list[2015].append(first_name[i])
	elif year_list[i]==2016:
		name_list[2016].append(first_name[i])
	elif year_list[i]==2017:
		name_list[2017].append(first_name[i])
	else:
		name_list[2018].append(first_name[i])
y=[0,0,0,0,0,0,0,0,0,0]
for k in range(2012,2019):
	fname_list=str(name_list[k])
	for ch in ",[]'《》，。：!‧「」『』〈〉；﹖.！ \n？":
  		fname_list = fname_list.replace(ch, "")
	letter_dict={}
	for char in fname_list:
	    if char in letter_dict:
	    	letter_dict[char] = letter_dict[char]+1
	    else:
	        letter_dict[char] = 1
	letter_sort = sorted(letter_dict.items(), key=lambda x:x[1], reverse=True)
	y[k-2012]=letter_sort
	letter_sort=0

#print(y[1])
#print(y[0][5][0])
cnt=[0,0,0,0,0,0,0,0,0,0]
#S=[[],[],[],[],[],[],[]]
for i in range(7):
	for k in range(len(y[i])):
		if y[i][k][0]=='宇':
			cnt[0]=y[i][k][1]
		elif y[i][k][0]=='文':
			cnt[1]=y[i][k][1]
		elif y[i][k][0]=='佳':
			cnt[2]=y[i][k][1]
		elif y[i][k][0]=='杰':
			cnt[3]=y[i][k][1]
		elif y[i][k][0]=='浩':
			cnt[4]=y[i][k][1]
		elif y[i][k][0]=='鑫':
			cnt[5]=y[i][k][1]
		elif y[i][k][0]=='子':
			cnt[6]=y[i][k][1]
		elif y[i][k][0]=='伟':
			cnt[7]=y[i][k][1]
		elif y[i][k][0]=='嘉':
			cnt[8]=y[i][k][1]
		elif y[i][k][0]=='雨':
			cnt[9]=y[i][k][1]
	x=['宇','文','佳','杰','浩','鑫','子','伟','嘉','雨']
	plt.title("常用字随年份变化趋势") 
	mpl.rcParams['font.sans-serif'] = ['SimHei']
	plt.plot(x,cnt, color='blue', label=2012+i)

	plt.legend() 
	plt.xlabel('年级')
	plt.ylabel('次数') 
	plt.show()








