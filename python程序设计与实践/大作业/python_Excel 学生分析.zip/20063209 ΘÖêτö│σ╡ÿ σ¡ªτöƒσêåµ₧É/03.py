from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from pylab import *
import xlrd
import pandas as pd

data=xlrd.open_workbook('python实验用名单.xls')
table=data.sheet_by_name('Sheet1')
name_list=table.col_values(0)[1:]
year_list=table.col_values(3)[1:]
last_name = []
for name in name_list:
   if '·' in name:
      name1, name2 = name.split("·")
      last_name.append(name1)
   elif len(name) == 4:
      last_name.append(name[:2])
   else:
      last_name.append(name[0:1])

name_list[2012],name_list[2013],name_list[2014],name_list[2015],name_list[2016],name_list[2017],name_list[2018]=[],[],[],[],[],[],[]
for i in range(len(last_name)):
	if year_list[i]==2012:
		name_list[2012].append(last_name[i])
	elif year_list[i]==2013:
		name_list[2013].append(last_name[i])
	elif year_list[i]==2014:
		name_list[2014].append(last_name[i])
	elif year_list[i]==2015:
		name_list[2015].append(last_name[i])
	elif year_list[i]==2016:
		name_list[2016].append(last_name[i])
	elif year_list[i]==2017:
		name_list[2017].append(last_name[i])
	else:
		name_list[2018].append(last_name[i])

array=[]
for k in range(2012,2019):
	last_num = defaultdict(int)
	for i in range(len(name_list[k])):
	   last_num[last_name[i]] += 1
	last_sort = sorted(last_num.items(), key=lambda x:x[1], reverse=True)
	#print(last_sort)
	cnts=[]
	total_cnt=0
	for tupe in last_sort:
	   cnts.append(tupe[1])
	for i in cnts:
	   total_cnt +=i
	a=int((cnts[0]/total_cnt)*100)
	b=int((cnts[1]/total_cnt)*100)
	c=int((cnts[2]/total_cnt)*100)
	d=int((cnts[3]/total_cnt)*100)
	if len(cnts)<=4:
		e=0
	else:
		e=int((cnts[4]/total_cnt)*100)
	array.append([a,b,c,d,e])
print(array)
vals = np.array(array)
fig, ax =plt.subplots(1,1)
column_labels=["NO.1/%","NO.2/%", "NO.3/%","NO.4/%","NO.5/%"]
df=pd.DataFrame(array,columns=column_labels)
ax.axis('tight')
ax.axis('off')
ax.table(cellText=df.values,
        colLabels=df.columns,
        rowLabels=["2012","2013","2014",'2015','2016','2017','2018'],
        loc="center")

plt.show()

